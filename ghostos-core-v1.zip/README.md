# GhostOS Core
Agentic backend for Ghost Tech Solutions.

## What is live in this starter
ATLAS manages RELAY, SUPPLY, LEDGER and DISPATCH. SUPPLY has live web search. Airtable remains the operating database. Purchases and consequential actions remain approval-gated.

## Owner setup
1. Deploy this folder/repo to Netlify.
2. In Netlify Environment Variables add OPENAI_API_KEY, AIRTABLE_PAT, AIRTABLE_BASE_ID, GHOSTOS_WEBHOOK_SECRET.
3. Point the lead webhook to `/api/ghostos` and send `x-ghostos-secret`.

Do not put API keys in source code or chat.
